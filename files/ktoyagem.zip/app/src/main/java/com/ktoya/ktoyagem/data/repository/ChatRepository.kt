package com.ktoya.ktoyagem.data.repository

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.ktoya.ktoyagem.data.local.ChatDao
import com.ktoya.ktoyagem.data.local.ChatEntity
import com.ktoya.ktoyagem.data.local.MessageEntity
import com.ktoya.ktoyagem.ui.chat.ChatMessage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.ByteArrayOutputStream

class ChatRepository(private val chatDao: ChatDao) {

    fun getAllChats(): Flow<List<ChatEntity>> = chatDao.getAllChats()

    fun getMessagesForChat(chatId: String): Flow<List<ChatMessage>> {
        return chatDao.getMessagesForChat(chatId).map { entities ->
            entities.map { entity ->
                ChatMessage(
                    id = entity.id.toString(),
                    text = entity.text,
                    participant = entity.participant,
                    images = entity.images.map { byteArrayToBitmap(it) }
                )
            }
        }
    }

    suspend fun saveChat(chat: ChatEntity) {
        chatDao.insertChat(chat)
    }

    suspend fun saveMessage(chatId: String, message: ChatMessage) {
        val entity = MessageEntity(
            chatId = chatId,
            text = message.text,
            participant = message.participant,
            images = message.images.map { bitmapToByteArray(it) }
        )
        chatDao.insertMessage(entity)
    }

    suspend fun deleteChat(chatId: String) {
        chatDao.deleteChat(chatId)
    }

    suspend fun clearHistory() {
        chatDao.clearHistory()
    }

    private fun bitmapToByteArray(bitmap: Bitmap): ByteArray {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        return stream.toByteArray()
    }

    private fun byteArrayToBitmap(byteArray: ByteArray): Bitmap {
        return BitmapFactory.decodeByteArray(byteArray, 0, byteArray.size)
    }
}
