package com.ktoya.ktoyagem.ui.theme

import androidx.compose.ui.graphics.Color

// Primary
val PrimaryLight = Color(0xFF005AC1)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFD8E2FF)
val OnPrimaryContainerLight = Color(0xFF001A41)

// Secondary
val SecondaryLight = Color(0xFF535E78)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFD8E2FF)
val OnSecondaryContainerLight = Color(0xFF0F1B32)

// Tertiary
val TertiaryLight = Color(0xFF75546F)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFFFD7F3)
val OnTertiaryContainerLight = Color(0xFF2C122A)

// Error
val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

// Background/Surface
val BackgroundLight = Color(0xFFFEFBFF)
val OnBackgroundLight = Color(0xFF1B1B1F)
val SurfaceLight = Color(0xFFFEFBFF)
val OnSurfaceLight = Color(0xFF1B1B1F)
val SurfaceVariantLight = Color(0xFFE1E2EC)
val OnSurfaceVariantLight = Color(0xFF44474F)
val OutlineLight = Color(0xFF74777F)

// Dark Palette
val PrimaryDark = Color(0xFFAEC6FF)
val OnPrimaryDark = Color(0xFF002E6C)
val PrimaryContainerDark = Color(0xFF004494)
val OnPrimaryContainerDark = Color(0xFFD8E2FF)

val SecondaryDark = Color(0xFFBBC7E4)
val OnSecondaryDark = Color(0xFF253048)
val SecondaryContainerDark = Color(0xFF3B475F)
val OnSecondaryContainerDark = Color(0xFFD8E2FF)

val TertiaryDark = Color(0xFFE3BADA)
val OnTertiaryDark = Color(0xFF43273F)
val TertiaryContainerDark = Color(0xFF5B3D56)
val OnTertiaryContainerDark = Color(0xFFFFD7F3)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF1B1B1F)
val OnBackgroundDark = Color(0xFFE3E2E6)
val SurfaceDark = Color(0xFF1B1B1F)
val OnSurfaceDark = Color(0xFFE3E2E6)
val SurfaceVariantDark = Color(0xFF44474F)
val OnSurfaceVariantDark = Color(0xFFC4C6D0)
val OutlineDark = Color(0xFF8E9099)
