package com.ktoya.ktoyagem.data.local

import androidx.room.TypeConverter
import com.ktoya.ktoyagem.ui.chat.Participant
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

class Converters {
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val listByteArrayType = Types.newParameterizedType(List::class.java, ByteArray::class.java)
    private val adapter = moshi.adapter<List<ByteArray>>(listByteArrayType)

    @TypeConverter
    fun fromParticipant(participant: Participant): String = participant.name

    @TypeConverter
    fun toParticipant(value: String): Participant = Participant.valueOf(value)

    @TypeConverter
    fun fromImages(images: List<ByteArray>): String {
        return adapter.toJson(images)
    }

    @TypeConverter
    fun toImages(value: String): List<ByteArray>? {
        return adapter.fromJson(value)
    }
}
