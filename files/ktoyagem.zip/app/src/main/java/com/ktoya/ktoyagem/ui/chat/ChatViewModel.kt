package com.ktoya.ktoyagem.ui.chat

import android.graphics.Bitmap
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.ktoya.ktoyagem.data.local.ChatEntity
import com.ktoya.ktoyagem.data.repository.ChatRepository
import com.ktoya.ktoyagem.security.ApiKeyStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(
    private val apiKeyStore: ApiKeyStore,
    private val chatRepository: ChatRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<ChatUiState>(ChatUiState.Idle)
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    private val _messages = mutableStateListOf<ChatMessage>()
    val messages: List<ChatMessage> = _messages

    private var generativeModel: GenerativeModel? = null
    private var currentChatId: String = UUID.randomUUID().toString()
    private var isNewChat: Boolean = true

    init {
        initializeGenerativeModel()
    }

    private fun initializeGenerativeModel() {
        val apiKey = apiKeyStore.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _uiState.value = ChatUiState.Error("API Key is missing. Please add it in Settings.")
            return
        }

        generativeModel = GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = apiKey
        )
        _uiState.value = ChatUiState.Idle
    }

    fun sendMessage(userMessage: String, selectedImages: List<Bitmap> = emptyList()) {
        val model = generativeModel ?: run {
            _uiState.value = ChatUiState.Error("Generative Model not initialized.")
            return
        }

        val userChatMsg = ChatMessage(
            text = userMessage,
            participant = Participant.USER,
            images = selectedImages
        )
        _messages.add(userChatMsg)
        _uiState.value = ChatUiState.Loading

        viewModelScope.launch {
            try {
                if (isNewChat) {
                    chatRepository.saveChat(ChatEntity(currentChatId, userMessage.take(20)))
                    isNewChat = false
                }
                chatRepository.saveMessage(currentChatId, userChatMsg)

                val response = model.generateContent(
                    content {
                        if (selectedImages.isNotEmpty()) {
                            selectedImages.forEach { image(it) }
                        }
                        text(userMessage)
                    }
                )
                
                response.text?.let { outputContent ->
                    val modelMsg = ChatMessage(
                        text = outputContent,
                        participant = Participant.MODEL
                    )
                    _messages.add(modelMsg)
                    chatRepository.saveMessage(currentChatId, modelMsg)
                }
                _uiState.value = ChatUiState.Idle
            } catch (e: Exception) {
                val errorMsg = ChatMessage(
                    text = e.localizedMessage ?: "Unknown error occurred",
                    participant = Participant.ERROR
                )
                _messages.add(errorMsg)
                _uiState.value = ChatUiState.Idle
            }
        }
    }

    fun loadChat(chatId: String) {
        currentChatId = chatId
        isNewChat = false
        _messages.clear()
        viewModelScope.launch {
            chatRepository.getMessagesForChat(chatId).collect {
                _messages.clear()
                _messages.addAll(it)
            }
        }
    }

    fun createNewChat() {
        currentChatId = UUID.randomUUID().toString()
        isNewChat = true
        _messages.clear()
    }
}

sealed interface ChatUiState {
    data object Idle : ChatUiState
    data object Loading : ChatUiState
    data class Error(val message: String) : ChatUiState
}
