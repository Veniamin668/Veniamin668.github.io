package com.ktoya.ktoyagem.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation3.ui.NavDisplay
import androidx.navigation3.runtime.NavEntry
import androidx.compose.ui.platform.LocalContext
import com.ktoya.ktoyagem.data.local.AppDatabase
import com.ktoya.ktoyagem.data.repository.ChatRepository
import com.ktoya.ktoyagem.security.ApiKeyStore
import com.ktoya.ktoyagem.ui.chat.ChatViewModel
import com.ktoya.ktoyagem.ui.chat.HistoryViewModel
import com.ktoya.ktoyagem.ui.components.GeminiHistoryAdaptiveScaffold
import com.ktoya.ktoyagem.ui.screens.*

@Composable
fun GeminiLiteNavHost(
    backStack: MutableList<Route>,
    modifier: Modifier = Modifier,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val apiKeyStore = ApiKeyStore(context)
    val repository = ChatRepository(AppDatabase.getDatabase(context).chatDao())
    val factory = AppViewModelFactory(apiKeyStore, repository)

    NavDisplay(
        backStack = backStack,
        onBack = onBack,
        modifier = modifier,
        entryProvider = { key ->
            when (key) {
                is Route.Chat -> NavEntry(key) {
                    val viewModel: ChatViewModel = viewModel(factory = factory)
                    LaunchedEffect(key.chatId) {
                        if (key.chatId != null) {
                            viewModel.loadChat(key.chatId)
                        } else {
                            viewModel.createNewChat()
                        }
                    }
                    ChatScreen(viewModel)
                }
                Route.History -> NavEntry(key) {
                    val historyViewModel: HistoryViewModel = viewModel(factory = factory)
                    val chatViewModel: ChatViewModel = viewModel(factory = factory)
                    GeminiHistoryAdaptiveScaffold(
                        historyViewModel = historyViewModel,
                        chatViewModel = chatViewModel
                    )
                }
                Route.Settings -> NavEntry(key) { SettingsScreen() }
            }
        }
    )
}
