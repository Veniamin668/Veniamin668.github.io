package com.ktoya.ktoyagem.ui.chat

import android.graphics.Bitmap
import java.util.UUID

enum class Participant {
    USER, MODEL, ERROR
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val participant: Participant,
    val isPending: Boolean = false,
    val images: List<Bitmap> = emptyList()
)
