package com.ktoya.ktoyagem

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Chat
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.adaptive.navigationsuite.NavigationSuiteScaffold
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.ktoya.ktoyagem.navigation.GeminiLiteNavHost
import com.ktoya.ktoyagem.navigation.Route
import com.ktoya.ktoyagem.ui.theme.KtoyagemTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KtoyagemTheme {
                val backStack = remember { mutableStateListOf<Route>(Route.Chat()) }
                
                NavigationSuiteScaffold(
                    modifier = Modifier.fillMaxSize(),
                    navigationSuiteItems = {
                        item(
                            selected = backStack.last() is Route.Chat,
                            onClick = {
                                if (backStack.last() !is Route.Chat) {
                                    backStack.clear()
                                    backStack.add(Route.Chat())
                                }
                            },
                            icon = { Icon(Icons.AutoMirrored.Rounded.Chat, contentDescription = "Chat") },
                            label = { Text("Chat") }
                        )
                        item(
                            selected = backStack.last() == Route.History,
                            onClick = {
                                if (backStack.last() != Route.History) {
                                    backStack.clear()
                                    backStack.add(Route.History)
                                }
                            },
                            icon = { Icon(Icons.Rounded.History, contentDescription = "History") },
                            label = { Text("History") }
                        )
                        item(
                            selected = backStack.last() == Route.Settings,
                            onClick = {
                                if (backStack.last() != Route.Settings) {
                                    backStack.clear()
                                    backStack.add(Route.Settings)
                                }
                            },
                            icon = { Icon(Icons.Rounded.Settings, contentDescription = "Settings") },
                            label = { Text("Settings") }
                        )
                    }
                ) {
                    GeminiLiteNavHost(
                        backStack = backStack,
                        modifier = Modifier.fillMaxSize(),
                        onBack = {
                            if (backStack.size > 1) {
                                backStack.removeAt(backStack.size - 1)
                            } else {
                                finish()
                            }
                        }
                    )
                }
            }
        }
    }
}
