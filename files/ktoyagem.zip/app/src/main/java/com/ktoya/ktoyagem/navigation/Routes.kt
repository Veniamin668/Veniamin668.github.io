package com.ktoya.ktoyagem.navigation

import kotlinx.serialization.Serializable

@Serializable
sealed interface Route {
    @Serializable
    data class Chat(val chatId: String? = null) : Route
    @Serializable
    data object History : Route
    @Serializable
    data object Settings : Route
}
