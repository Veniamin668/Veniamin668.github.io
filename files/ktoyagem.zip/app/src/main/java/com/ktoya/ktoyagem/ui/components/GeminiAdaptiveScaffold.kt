package com.ktoya.ktoyagem.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.material3.adaptive.ExperimentalMaterial3AdaptiveApi
import androidx.compose.material3.adaptive.layout.ListDetailPaneScaffold
import androidx.compose.material3.adaptive.layout.ListDetailPaneScaffoldRole
import androidx.compose.material3.adaptive.navigation.rememberListDetailPaneScaffoldNavigator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import com.ktoya.ktoyagem.ui.chat.ChatViewModel
import com.ktoya.ktoyagem.ui.chat.HistoryViewModel
import com.ktoya.ktoyagem.ui.screens.ChatScreen
import com.ktoya.ktoyagem.ui.screens.HistoryScreen
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3AdaptiveApi::class)
@Composable
fun GeminiHistoryAdaptiveScaffold(
    historyViewModel: HistoryViewModel,
    chatViewModel: ChatViewModel
) {
    val navigator = rememberListDetailPaneScaffoldNavigator<String>()
    val scope = rememberCoroutineScope()

    BackHandler(navigator.canNavigateBack()) {
        scope.launch {
            navigator.navigateBack()
        }
    }

    ListDetailPaneScaffold(
        directive = navigator.scaffoldDirective,
        value = navigator.scaffoldValue,
        listPane = {
            HistoryScreen(
                historyViewModel = historyViewModel,
                onChatSelected = { chatId ->
                    chatViewModel.loadChat(chatId)
                    scope.launch {
                        navigator.navigateTo(ListDetailPaneScaffoldRole.Detail, chatId)
                    }
                }
            )
        },
        detailPane = {
            val chatId = navigator.currentDestination?.contentKey
            if (chatId != null) {
                ChatScreen(chatViewModel = chatViewModel)
            }
        }
    )
}
