# Gemini AI Chat UI Implementation Plan

Build the core Chat UI and integrate the Gemini AI SDK into the Gemini Lite project.

## User Review Required

> [!IMPORTANT]
> The implementation assumes that an API key is already stored in `ApiKeyStore`. If not, the app will show an error state prompting the user to provide an API key (likely in the Settings screen, which is currently a placeholder).

## Proposed Changes

### [Chat Component]

#### [NEW] [ChatMessage.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/chat/ChatMessage.kt)
Data class to represent chat messages.

#### [NEW] [ChatViewModel.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/chat/ChatViewModel.kt)
ViewModel to manage chat state and Gemini SDK interaction.

#### [MODIFY] [Screens.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/screens/Screens.kt)
Replace the `ChatScreen` placeholder with a full Material 3 chat interface.

## Verification Plan

### Automated Tests
- Build the project using `./gradlew :app:assembleDebug`.

### Manual Verification
- Verify the chat UI layout.
- Test sending a message and receiving a response from Gemini.
- Verify loading state during AI processing.
- Verify error state if API key is missing.
