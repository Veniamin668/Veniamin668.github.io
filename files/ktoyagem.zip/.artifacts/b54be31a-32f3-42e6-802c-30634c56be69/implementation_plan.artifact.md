# UI Refinement and Adaptive Design Plan

Refine the Gemini Lite app's UI to support multiple device form factors (phones, tablets, foldables) using Compose Material 3 Adaptive components and finalize the Material 3 styling.

## User Review Required

> [!IMPORTANT]
> The navigation structure will be updated to use `NavigationSuiteScaffold`, which might change the UI layout on larger screens (e.g., switching from a bottom bar to a navigation rail).

## Proposed Changes

### Theme and Styling
Refine the color scheme and typography to be more expressive and consistent with Material 3 guidelines.

#### [MODIFY] [Color.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/theme/Color.kt)
- Add a more comprehensive set of Material 3 color tokens.
- Use vibrant and energetic colors.

#### [MODIFY] [Theme.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/theme/Theme.kt)
- Update `lightColorScheme` and `darkColorScheme` with the new tokens.
- Ensure all Material 3 attributes are covered.

### Adaptive Navigation
Update the main entry point to use adaptive navigation components.

#### [MODIFY] [MainActivity.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/MainActivity.kt)
- Replace `Scaffold` and `NavigationBar` with `NavigationSuiteScaffold`.
- Integrate `adaptive-navigation3` for state management.
- Ensure edge-to-edge is properly handled.

### Adaptive Layouts
Implement adaptive scaffolds for features that benefit from multi-pane layouts.

#### [NEW] [GeminiAdaptiveScaffold.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/ui/components/GeminiAdaptiveScaffold.kt)
- Create a reusable adaptive scaffold using `ListDetailPaneScaffold` or `SupportingPaneScaffold` to handle different screen configurations.

#### [MODIFY] [GeminiLiteNavHost.kt](file:///C:/Users/ktoya/AndroidStudioProjects/ktoyagem/app/src/main/java/com/ktoya/ktoyagem/navigation/GeminiLiteNavHost.kt)
- Update the navigation host to utilize the adaptive scaffold for specific routes (e.g., History/Chat).

## Verification Plan

### Automated Tests
- Build the project using `./gradlew assembleDebug`.
- Run existing unit tests: `./gradlew testDebugUnitTest`.

### Manual Verification
- Verify the UI on different screen sizes (phone, tablet) using Compose Previews.
- Check for consistent Material 3 styling and smooth transitions.
- Ensure the app is stable and responsive.
