#!/system/bin/sh

# 1. Wait for complete boot
until [ "$(getprop sys.boot_completed)" -eq 1 ]; do
    echo "0" > /proc/sys/kernel/printk
    setprop ctl.stop console
    setprop ctl.stop setup_console
    sleep 2
done

# 2. Pure BAT-script loop without logd/logcat overhead
while true; do
    # Kill core kernel printk spam
    echo "0" > /proc/sys/kernel/printk
    
    # Kill only console services
    setprop ctl.stop console
    setprop ctl.stop setup_console
    
    # Push true Unisoc false state
    setprop persist.sys.uart.status false
    setprop persist.vendor.uart.status false
    setprop persist.vendor.serial.debug 0
    



    
    # Check status to adapt sleep
    STATUS=$(getprop init.svc.console)
    if [ "$STATUS" = "running" ]; then
        sleep 0.5
    else
        sleep 3
    fi
done
