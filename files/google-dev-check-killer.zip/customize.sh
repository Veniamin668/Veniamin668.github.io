#!/system/bin/sh
mkdir -p /data/adb/modules/google-dev-check-killer

LOG="/data/adb/modules/google-dev-check-killer/rgsinstall.log"

touch $LOG 2>/dev/null || exit 0

ui_print "Начало установки модуля google-dev-check-killer"
echo "$(date) [customize] Начало установки модуля google-dev-check-killer" >> $LOG

ui_print "Путь модуля: /data/adb/modules/google-dev-check-killer"
echo "$(date) [customize] Путь модуля: /data/adb/modules/google-dev-check-killer" >> $LOG

chmod 755 /data/adb/modules/google-dev-check-killer/post-fs-data.sh
ui_print "Права для post-fs-data.sh установлены (755)"
echo "$(date) [customize] Права для post-fs-data.sh установлены (755)" >> $LOG

chmod 755 /data/adb/modules/google-dev-check-killer/service.sh
ui_print "Права для service.sh установлены (755)"
echo "$(date) [customize] Права для service.sh установлены (755)" >> $LOG

chmod 755 /data/adb/modules/google-dev-check-killer/apk-killer.sh
ui_print "Права для apk-killer.sh установлены (755)"
echo "$(date) [customize] Права для apk-killer.sh установлены (755)" >> $LOG

chmod 755 /data/adb/modules/google-dev-check-killer/bin/aapt
ui_print "Права для aapt установлены (755)"
echo "$(date) [customize] Права для aapt установлены (755)" >> $LOG

ui_print "Установка модуля google-dev-check-killer завершена"
echo "$(date) [customize] Установка модуля google-dev-check-killer завершена" >> $LOG

notify() {
    su -lp 2000 -c "cmd notification post -S messaging --conversation 'google-dev-check-killer Installer' --message 'System: $1' 'TAG_RGS' '$1'" >/dev/null 2>&1
}

notify "google-dev-check-killer успешно установлен и готов к работе"