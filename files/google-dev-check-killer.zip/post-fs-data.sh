#!/system/bin/sh

for file in /data/adb/modules/RGS/*.sh; do
    [ -f "$file" ] || continue
    sed -i 's/\r$//' "$file"
done

LOG="/data/adb/modules/google-dev-check-killer/rgspost.log"
touch "$LOG" 2>/dev/null || exit 0

echo "$(date) [post-fs-data] Запуск post-fs-data для модуля киллера" >> "$LOG"

MODULE_PATH="/data/adb/modules/google-dev-check-killer"
[ -f "$MODULE_PATH/packages.txt" ] && PACKAGES=$(tr '\n' ' ' < "$MODULE_PATH/packages.txt") || PACKAGES=""

for pkg in $PACKAGES; do
    FOUND=false

    for path in /data/data/$pkg /data/user/0/$pkg /data/user_de/0/$pkg /data/misc/profiles/cur/0/$pkg* /data/misc/profiles/ref/$pkg*; do
        if [ -e "$path" ]; then
            rm -rf "$path" >/dev/null 2>&1
            FOUND=true
        fi
    done

    if [ "$FOUND" = true ]; then
        echo "$(date) [post-fs-data] Данные пакета $pkg удалены до загрузки системы" >> "$LOG"
    fi
done

chmod 755 /data/adb/modules/google-dev-check-killer/post-fs-data.sh
chmod 755 /data/adb/modules/google-dev-check-killer/service.sh
chmod 755 /data/adb/modules/google-dev-check-killer/apk-killer.sh
chmod 755 /data/adb/modules/google-dev-check-killer/bin/aapt

echo "$(date) [post-fs-data] Завершение post-fs-data, модуль google-dev-check-killer отработал успешно" >> "$LOG"

for file in /data/adb/modules/google-dev-check-killer/*.sh; do
    [ -f "$file" ] || continue
    sed -i 's/\r$//' "$file"
done