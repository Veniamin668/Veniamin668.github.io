#!/system/bin/sh

LOG="/data/adb/modules/RGS/rgsmain.log"
touch $LOG 2>/dev/null || exit 0

MODULE_PATH="/data/adb/modules/RGS"
[ -f "$MODULE_PATH/packages.txt" ] && PACKAGES=$(tr '\n' ' ' < "$MODULE_PATH/packages.txt") || PACKAGES="ru.oneme.app ru.vk.store"

MSG_START="убивание чекера разраба вырублено успешно."
MSG_BOOT="Система успешно загрузилась."
MSG_KILL_SUCCESS="Пакет успешно удалён."

echo "$(date) [service] $MSG_START" >> $LOG

while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

echo "$(date) [service] $MSG_BOOT" >> $LOG

HAS_SU=0
if command -v su >/dev/null 2>&1; then
    HAS_SU=1
fi

HAS_PM=0
if command -v pm >/dev/null 2>&1; then
    HAS_PM=1
fi

sh /data/adb/modules/RGS/apk-killer.sh &

notify() {
    su -lp 2000 -c "cmd notification post -S messaging --conversation 'RGS' --message 'System: $1' 'TAG_RGS' '$1'" >/dev/null 2>&1
}

notify "Система загрузилась. Начинаю удаление нежелательных приложений."

while true; do
    for pkg in $PACKAGES; do
        APK_PATH=$(pm path $pkg 2>/dev/null | sed 's/package://')
        APP_NAME=$(/data/adb/modules/RGS/bin/aapt d badging "$APK_PATH" 2>/dev/null | grep "application-label:" | awk -F"'" '{print $2}')
        [ -z "$APP_NAME" ] && APP_NAME="$pkg"

        if echo "$APP_NAME" | grep -E "Проверка разработчика Android|Android Developer Verifier" >/dev/null 2>&1; then
            APP_NAME="$APP_NAME"
        fi

        if [ $HAS_SU -eq 1 ]; then
            if su -c "pm uninstall --user 0 $pkg" >/dev/null 2>&1; then
                echo "$(date) [service] $APP_NAME ($pkg) успешно удалён." >> $LOG
                notify "$APP_NAME ($pkg) успешно удалён."
            fi
        elif [ $HAS_PM -eq 1 ]; then
            if pm uninstall --user 0 "$pkg" >/dev/null 2>&1; then
                echo "$(date) [service] $APP_NAME ($pkg) успешно удалён." >> $LOG
                notify "$APP_NAME ($pkg) успешно удалён."
            fi
        fi
    done
    sleep 5
done