#!/system/bin/sh

MODULE_PATH="/data/adb/modules/google-dev-check-killer"
LOG="$MODULE_PATH/rgsapkrem.log"
touch "$LOG" 2>/dev/null || exit 0

PACKAGES=$(cat "$MODULE_PATH/packages.txt" 2>/dev/null)
APP_NAMES=$(cat "$MODULE_PATH/apps.txt" 2>/dev/null)
WATCHED_DIRS=$(cat "$MODULE_PATH/cdirs.txt" 2>/dev/null)

EXTS="apk ap apks xapk apkm"

notify() {
    su -lp 2000 -c "cmd notification post -S messaging --conversation 'google-dev-check-killer' --message 'System:$1' 'TAG_google-dev-check-killer' '$1'" >/dev/null 2>&1
}

while true; do
    for dir in $WATCHED_DIRS; do
        for ext in $EXTS; do
            for file in "$dir"/*.$ext; do
                [ -f "$file" ] || continue

                PKG=$("$MODULE_PATH/bin/aapt" d badging "$file" 2>/dev/null | grep package:\ name | awk -F"'" '{print $2}')
                APP=$("$MODULE_PATH/bin/aapt" d badging "$file" 2>/dev/null | grep "application-label:" | head -n1 | awk -F"'" '{print $2}')

                for i in $(seq 1 $(echo $PACKAGES | wc -w)); do
                    TARGET_PKG=$(echo $PACKAGES | cut -d' ' -f$i)
                    TARGET_APP=$(echo $APP_NAMES | cut -d' ' -f$i)

                    if [ "$PKG" = "$TARGET_PKG" ] || [ "$APP" = "$TARGET_APP" ]; then
                        if command -v su >/dev/null 2>&1; then
                            su -c "rm -f \"$file\""
                        else
                            rm -f "$file"
                        fi

                        echo "$(date) [apk-killer] Файл по пути $file с пакетом $PKG и именем приложения $APP уничтожен до установки!" >> $LOG
                        notify "$APP ($PKG) убит до установки!"
                    fi
                done
            done
        done
    done
    sleep 5
done