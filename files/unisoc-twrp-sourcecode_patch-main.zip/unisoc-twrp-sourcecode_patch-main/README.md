# TWRP DRM Refactor for Unisoc (SPRD) Platforms

**Author: rtyutechstudio**

---

## Overview

This repository contains a refactored `graphics_drm.cpp` implementation for TWRP that resolves the long-standing display initialization issues on Unisoc (Spreadtrum) platforms. The refactor replaces the problematic Qualcomm/SDE atomic DRM code path with a legacy DRM interface that works reliably on Unisoc SoCs including T606, T616, T760, and others.

---

## The Problem

Users building TWRP for Unisoc-based devices frequently encounter the same set of symptoms:

- TWRP flashes successfully but the device **stucks at the boot logo** (OEM logo, not TWRP splash)
- Screen turns off when power button is pressed and turns back on when pressed again, but the logo remains frozen
- **ADB does not detect** the device in this state
- Touch and brightness may appear functional, but **TWRP UI never renders**

These issues are consistently reported across multiple Unisoc devices:

| Device | SoC | Reference |
|--------|-----|-----------|
| Coolpad Y60 lite | Unisoc T760 | [Thread](https://www.hovatek.com/forum/post-250272.html) |
| Symphony Z60 Plus | Unisoc T616 | [Thread](https://www.hovatek.com/forum/thread-49133.html) |
| Teclast T40 Air | Unisoc T616 | [Thread](https://www.hovatek.com/forum/thread-47656.html) |

The root cause is the **SPRD DRM incompatibility** with the Qualcomm/SDE atomic mode-setting code path that is enabled by default in TWRP's `graphics_drm.cpp`.

---

## Solution

This refactor fundamentally rewrites the DRM display path in `bootable/recovery/minuitwrp/graphics_drm.cpp` with the following core changes:

### 1. Remove Atomic DRM Code Path

- **Disabled** `DRM_CLIENT_CAP_ATOMIC` capability during initialization
- **Removed** all Qualcomm/SDE atomic topology, plane, and mode blob enumeration logic
- The initialization no longer attempts to query or configure atomic DRM objects

### 2. Legacy CRTC Control for Blank/Unblank

- Replaced atomic `drmModeAtomicCommit()` with **legacy `drmModeSetCrtc()`** for blank/unblank operations
- This ensures frame buffer control works on Unisoc's DRM implementation without requiring atomic support

### 3. Page Flip with Fallback

- Display refresh now uses **`drmModePageFlip()`** for efficient frame updates
- On failure, automatically **fallback to `drmModeSetCrtc()`** to guarantee display output

### 4. Legacy CRTC Disable for Non-Main Outputs

- `disable_non_main_crtcs()` now uses legacy `drmModeSetCrtc(... fb=0 ...)` instead of atomic commit
- Properly disables unused CRTCs without relying on atomic interfaces

---

## Technical Implementation Details

### Before (Atomic Path)

```cpp
// Atomic initialization
drmSetClientCap(fd, DRM_CLIENT_CAP_ATOMIC, 1);
// Enumerate planes, topology, mode blobs
// Atomic commit for blank/unblank
drmModeAtomicCommit(fd, req, 0, NULL);
```

### After (Legacy Path)

```cpp
// No atomic capability set
// Legacy CRTC operations
drmModeSetCrtc(fd, crtc_id, fb_id, x, y, &conn_id, 1, &mode);
// Page flip with fallback
if (drmModePageFlip(fd, crtc_id, fb_id, DRM_MODE_PAGE_FLIP_EVENT, &data) < 0) {
    drmModeSetCrtc(fd, crtc_id, fb_id, x, y, &conn_id, 1, &mode);
}
```

---

## Usage

### Prerequisites

- TWRP source tree (Android 12/13 based)
- Unisoc device tree with proper kernel headers

### Integration

1. Replace `bootable/recovery/minuitwrp/graphics_drm.cpp` with the refactored version
2. Build TWRP as usual:
   ```bash
   source build/envsetup.sh
   lunch twrp_<device>-eng
   make -j$(nproc) recoveryimage
   ```

### Device-Specific Notes

- For devices with **vendor_boot** (A/B partitions), flash the generated `vendor_boot.img`
- For devices without recovery partition, use the boot + vendor_boot method

---

## References

- [TWRP touch issues on Teclast T40 Air (Unisoc T616)](https://www.hovatek.com/forum/thread-47656.html)
- [TWRP Coolpad Y60 lite (T760, android 13)](https://www.hovatek.com/forum/post-250272.html)
- [TWRP UI doesn't appear (Unisoc)(vendor_boot)](https://www.hovatek.com/forum/thread-49133.html)
- [Unisoc Android Recovery Source](https://github.com/unisoc-android/android_bootable_recovery)

---

## Credits

- **Author**: rtyutechstudio
- Special thanks to the TWRP community and Hovatek forum members for extensive testing and feedback on Unisoc devices

---

## License

This work is based on the TWRP open-source project and is distributed under the same license terms.